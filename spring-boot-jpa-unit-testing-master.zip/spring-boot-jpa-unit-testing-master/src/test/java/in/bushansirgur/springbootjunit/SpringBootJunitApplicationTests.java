package in.bushansirgur.springbootjunit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJunitApplicationTests {

	@Test
	void contextLoads() {
	}

}
